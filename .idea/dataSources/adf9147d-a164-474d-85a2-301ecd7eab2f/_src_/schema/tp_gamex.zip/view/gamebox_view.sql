CREATE VIEW gamebox_view AS
  SELECT
    `tp_gamex`.`gem_gamebox`.`id`         AS `id`,
    `tp_gamex`.`gem_gamebox`.`cid`        AS `cid`,
    `tp_gamex`.`gem_gamebox`.`fid`        AS `fid`,
    `tp_gamex`.`gem_gamebox`.`title`      AS `title`,
    `tp_gamex`.`gem_gamebox`.`platform`   AS `platform`,
    `tp_gamex`.`gem_gamebox`.`litpic`     AS `litpic`,
    `tp_gamex`.`gem_gamebox`.`banner`     AS `banner`,
    `tp_gamex`.`gem_gamebox`.`url`        AS `url`,
    `tp_gamex`.`gem_gamebox`.`keyword`    AS `keyword`,
    `tp_gamex`.`gem_gamebox`.`keydesc`    AS `keydesc`,
    `tp_gamex`.`gem_gamebox`.`cdatetimes` AS `cdatetimes`,
    `tp_gamex`.`gem_gamebox`.`udatetimes` AS `udatetimes`
  FROM `tp_gamex`.`gem_gamebox`;
