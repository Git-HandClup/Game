CREATE TRIGGER lc_news_insert
AFTER INSERT ON gem_news
FOR EACH ROW
  BEGIN

update lc_catalog set `total`=`total`+1 where id=new.cid;
update lc_catalog set `total`=`total`+1 where id in
(
    select a.cid from(
          select cid from lc_catalog where id=new.cid
    )a
);

END;
