CREATE TRIGGER lc_news_delete
AFTER DELETE ON gem_news
FOR EACH ROW
  BEGIN

DELETE from lc_news_data where aid=old.id;

END;
